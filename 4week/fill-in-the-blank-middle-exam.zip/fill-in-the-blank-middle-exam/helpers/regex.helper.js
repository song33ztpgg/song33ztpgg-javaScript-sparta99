exports.isRegexValidation = (target, regex) => {
  return target.search(regex) !== -1;
};
