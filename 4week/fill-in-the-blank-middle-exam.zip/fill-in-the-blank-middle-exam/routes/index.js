const express = require('express');
const router = express.Router();

// Exam 1

module.exports = router;
